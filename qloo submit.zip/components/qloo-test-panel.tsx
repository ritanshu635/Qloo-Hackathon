"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Loader2, CheckCircle, XCircle, Zap } from "lucide-react"

export default function QlooTestPanel() {
  const [isLoading, setIsLoading] = useState(false)
  const [testResult, setTestResult] = useState<any>(null)

  const testQlooConnection = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/qloo-test")
      const result = await response.json()
      setTestResult(result)
    } catch (error) {
      setTestResult({
        status: "error",
        message: "Failed to connect to test endpoint",
        error: error instanceof Error ? error.message : "Unknown error",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="h-5 w-5 text-purple-600" />
          Qloo API Connection Test
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Button
          onClick={testQlooConnection}
          disabled={isLoading}
          className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Testing Connection...
            </>
          ) : (
            "Test Qloo API Connection"
          )}
        </Button>

        {testResult && (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              {testResult.status === "success" ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <XCircle className="h-5 w-5 text-red-600" />
              )}
              <Badge variant={testResult.status === "success" ? "default" : "destructive"}>
                {testResult.status.toUpperCase()}
              </Badge>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="font-medium mb-2">Status:</p>
              <p className="text-sm text-gray-700">{testResult.message}</p>
            </div>

            {testResult.error && (
              <div className="bg-red-50 p-4 rounded-lg">
                <p className="font-medium text-red-800 mb-2">Error Details:</p>
                <p className="text-sm text-red-700">{testResult.error}</p>
              </div>
            )}

            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="font-medium text-blue-800 mb-2">Configuration:</p>
              <div className="text-sm text-blue-700 space-y-1">
                <p>API URL: {testResult.apiUrl || "Not set"}</p>
                <p>API Key: {testResult.hasApiKey ? "✅ Configured" : "❌ Missing"}</p>
              </div>
            </div>

            {testResult.sampleRecommendations && testResult.sampleRecommendations.length > 0 && (
              <div className="bg-green-50 p-4 rounded-lg">
                <p className="font-medium text-green-800 mb-2">Sample Recommendations:</p>
                <div className="space-y-2">
                  {testResult.sampleRecommendations.map((rec: any, index: number) => (
                    <div key={index} className="text-sm text-green-700">
                      <p className="font-medium">{rec.name}</p>
                      <p>Score: {rec.score}/10</p>
                      {rec.explanation && <p className="italic">"{rec.explanation}"</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
