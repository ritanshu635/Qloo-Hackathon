"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Heart, Sparkles, Music, Coffee, MapPin, Camera, Users, BookOpen, Brain, Smile, Globe } from "lucide-react"
import DebugPanel from "@/components/debug-panel"

interface LandingPageProps {
  onStartJourney: () => void
}

export default function LandingPage({ onStartJourney }: LandingPageProps) {
  const features = [
    {
      icon: Brain,
      title: "Taste DNA Analysis",
      description: "Deep understanding of your preferences in music, movies, fashion, and food",
      color: "from-purple-500 to-pink-500",
    },
    {
      icon: Smile,
      title: "Mood Detection",
      description: "Recognizes your emotional state and responds with perfect empathy",
      color: "from-blue-500 to-cyan-500",
    },
    {
      icon: Heart,
      title: "Emotional Response",
      description: "Provides comfort, celebration, or motivation based on how you feel",
      color: "from-red-500 to-pink-500",
    },
    {
      icon: MapPin,
      title: "Local Taste Map",
      description: "Discovers places that match your emotional and taste profile",
      color: "from-green-500 to-emerald-500",
    },
    {
      icon: Users,
      title: "Character Options",
      description: "Choose your companion's personality - from witty to gentle",
      color: "from-orange-500 to-yellow-500",
    },
    {
      icon: Globe,
      title: "Travel Mode",
      description: "Plans perfect escapes based on your current mood and preferences",
      color: "from-indigo-500 to-purple-500",
    },
    {
      icon: Camera,
      title: "Moodboard Generator",
      description: "Creates visual representations of your current vibe and taste",
      color: "from-teal-500 to-blue-500",
    },
    {
      icon: BookOpen,
      title: "Memory Capsule",
      description: "Your personal nostalgia diary with cultural artifacts",
      color: "from-pink-500 to-rose-500",
    },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 px-4">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 via-pink-600/20 to-blue-600/20" />
        <div className="relative max-w-7xl mx-auto text-center">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <h1 className="text-6xl md:text-8xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 bg-clip-text text-transparent mb-6">
              Meet Gogo
            </h1>
            <p className="text-2xl md:text-3xl text-gray-700 mb-4 font-light">Your Emotion + Taste Companion AI</p>
            <p className="text-lg md:text-xl text-gray-600 mb-12 max-w-3xl mx-auto leading-relaxed">
              The world's first AI companion that understands both your emotions and cultural taste. Whether you're
              happy, sad, excited, or contemplative - Gogo knows exactly what you need.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16"
          >
            <Button
              onClick={onStartJourney}
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-4 text-lg rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <Sparkles className="mr-2 h-5 w-5" />
              Start Your Journey
            </Button>
          </motion.div>

          {/* Floating Elements */}
          <div className="absolute top-20 left-10 animate-bounce">
            <Music className="h-8 w-8 text-purple-400" />
          </div>
          <div className="absolute top-32 right-16 animate-pulse">
            <Heart className="h-6 w-6 text-pink-400" />
          </div>
          <div className="absolute bottom-20 left-20 animate-bounce delay-1000">
            <Coffee className="h-7 w-7 text-orange-400" />
          </div>
        </div>
      </section>

      {/* Debug Panel - REMOVE THIS AFTER TESTING */}
      <section className="py-20 px-4 bg-red-50 border-t-4 border-red-200">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-8"
          >
            <h2 className="text-3xl font-bold text-red-800 mb-4">🚨 DEBUG MODE - API Testing</h2>
            <p className="text-red-600">
              This section will be removed after testing. Use this to check if your APIs are working.
            </p>
          </motion.div>
          <DebugPanel />
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 px-4 bg-white/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">Why Gogo is Different</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Unlike other AI assistants, Gogo combines emotional intelligence with deep cultural understanding
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="h-full hover:shadow-xl transition-all duration-300 border-0 bg-white/80 backdrop-blur-sm">
                  <CardContent className="p-6 text-center">
                    <div
                      className={`w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r ${feature.color} flex items-center justify-center`}
                    >
                      <feature.icon className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-3">{feature.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600">
        <div className="max-w-4xl mx-auto text-center text-white">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Ready to Meet Your Perfect Companion?</h2>
            <p className="text-xl mb-8 opacity-90">
              Join thousands who've discovered their ideal AI companion that truly understands them
            </p>
            <Button
              onClick={onStartJourney}
              size="lg"
              className="bg-white text-purple-600 hover:bg-gray-100 px-8 py-4 text-lg rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <Heart className="mr-2 h-5 w-5" />
              Create Your Gogo Now
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Sparkles className="h-6 w-6 text-purple-400" />
            <span className="text-2xl font-bold">Gogo</span>
          </div>
          <p className="text-gray-400 mb-6">Your Emotion + Taste Companion AI</p>
          <div className="flex justify-center gap-6 text-sm text-gray-400">
            <span>Built for Qloo Hackathon 2025</span>
            <span>•</span>
            <span>Powered by OpenAI & Qloo</span>
          </div>
        </div>
      </footer>
    </div>
  )
}
