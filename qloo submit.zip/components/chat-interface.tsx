"use client"

import { useState, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import {
  Send,
  Frown,
  Meh,
  Heart,
  Zap,
  Coffee,
  Music,
  MapPin,
  Shirt,
  Film,
  ArrowLeft,
  Sparkles,
  Sun,
  Cloud,
  CloudRain,
  Moon,
} from "lucide-react"
import type { UserPreferences, MoodType } from "@/types/user"
import { useChat } from "@ai-sdk/react"

interface ChatInterfaceProps {
  userPreferences: UserPreferences
  chatbotName: string
  onBack: () => void
}

export default function ChatInterface({ userPreferences, chatbotName, onBack }: ChatInterfaceProps) {
  const [currentMood, setCurrentMood] = useState<MoodType>("neutral")
  const [showMoodSelector, setShowMoodSelector] = useState(false)
  const [uiTheme, setUiTheme] = useState("default")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: "/api/chat",
    initialMessages: [
      {
        id: "1",
        role: "assistant",
        content: `Hey ${userPreferences.name || "there"}! I'm ${chatbotName}, your personal companion who understands both your emotions and your amazing taste! 🌟

I've learned about your preferences:
${userPreferences.musicGenres?.length ? `🎵 Music: ${userPreferences.musicGenres.slice(0, 3).join(", ")}` : ""}
${userPreferences.movieGenres?.length ? `🎬 Movies: ${userPreferences.movieGenres.slice(0, 3).join(", ")}` : ""}
${userPreferences.foodTypes?.length ? `🍽️ Food: ${userPreferences.foodTypes.slice(0, 3).join(", ")}` : ""}
${userPreferences.fashionStyle?.length ? `👗 Style: ${userPreferences.fashionStyle.slice(0, 2).join(", ")}` : ""}

How are you feeling today? I'm here to chat, recommend, and understand exactly what you need! ✨`,
      },
    ],
    body: {
      userPreferences,
      currentMood,
      chatbotName,
    },
    onFinish: (message) => {
      console.log("✅ Message received in frontend:", message.content.substring(0, 100) + "...")
    },
  })

  const moods = [
    {
      type: "happy" as MoodType,
      icon: Sun,
      label: "Happy",
      color: "from-yellow-400 to-orange-400",
      bgColor: "bg-yellow-50",
    },
    {
      type: "sad" as MoodType,
      icon: CloudRain,
      label: "Sad",
      color: "from-blue-400 to-indigo-400",
      bgColor: "bg-blue-50",
    },
    {
      type: "excited" as MoodType,
      icon: Zap,
      label: "Excited",
      color: "from-pink-400 to-red-400",
      bgColor: "bg-pink-50",
    },
    {
      type: "calm" as MoodType,
      icon: Cloud,
      label: "Calm",
      color: "from-green-400 to-teal-400",
      bgColor: "bg-green-50",
    },
    {
      type: "anxious" as MoodType,
      icon: Frown,
      label: "Anxious",
      color: "from-purple-400 to-indigo-400",
      bgColor: "bg-purple-50",
    },
    {
      type: "nostalgic" as MoodType,
      icon: Moon,
      label: "Nostalgic",
      color: "from-indigo-400 to-purple-400",
      bgColor: "bg-indigo-50",
    },
    {
      type: "neutral" as MoodType,
      icon: Meh,
      label: "Neutral",
      color: "from-gray-400 to-gray-500",
      bgColor: "bg-gray-50",
    },
    {
      type: "romantic" as MoodType,
      icon: Heart,
      label: "Romantic",
      color: "from-rose-400 to-pink-400",
      bgColor: "bg-rose-50",
    },
  ]

  const currentMoodData = moods.find((m) => m.type === currentMood) || moods[6]

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  useEffect(() => {
    // Change UI theme based on mood
    const moodThemes = {
      happy: "from-yellow-50 via-orange-50 to-pink-50",
      sad: "from-blue-50 via-indigo-50 to-purple-50",
      excited: "from-pink-50 via-red-50 to-orange-50",
      calm: "from-green-50 via-teal-50 to-blue-50",
      anxious: "from-purple-50 via-indigo-50 to-blue-50",
      nostalgic: "from-indigo-50 via-purple-50 to-pink-50",
      neutral: "from-gray-50 via-slate-50 to-zinc-50",
      romantic: "from-rose-50 via-pink-50 to-red-50",
    }
    setUiTheme(moodThemes[currentMood])
  }, [currentMood])

  const quickActions = [
    { icon: Music, label: "Music Rec", prompt: "I want to listen to some music that matches my current mood" },
    { icon: Coffee, label: "Food Spot", prompt: "Suggest a place to eat based on how I'm feeling" },
    { icon: Film, label: "Movie Night", prompt: "Recommend a movie for my current mood" },
    { icon: Shirt, label: "Outfit Ideas", prompt: "Help me choose what to wear today" },
    { icon: MapPin, label: "Go Somewhere", prompt: "I want to go somewhere that fits my vibe" },
    { icon: Heart, label: "Cheer Me Up", prompt: "I need some emotional support and comfort" },
  ]

  const handleQuickAction = (prompt: string) => {
    handleSubmit(new Event("submit") as any, { data: { message: prompt } })
  }

  const handleMoodChange = (mood: MoodType) => {
    setCurrentMood(mood)
    setShowMoodSelector(false)
    // Send mood update to chat
    const moodMessage = `I'm feeling ${mood} right now.`
    handleSubmit(new Event("submit") as any, { data: { message: moodMessage } })
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br ${uiTheme} transition-all duration-1000`}>
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white/80 backdrop-blur-md border-b border-white/20 shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={onBack} className="hover:bg-white/50">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
              <div className="flex items-center gap-3">
                <div
                  className={`w-10 h-10 rounded-full bg-gradient-to-r ${currentMoodData.color} flex items-center justify-center`}
                >
                  <Sparkles className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h1 className="font-bold text-lg text-gray-800">{chatbotName}</h1>
                  <p className="text-sm text-gray-600">Your Emotion + Taste Companion</p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowMoodSelector(!showMoodSelector)}
                className={`${currentMoodData.bgColor} border-0 hover:bg-opacity-80`}
              >
                <currentMoodData.icon className="h-4 w-4 mr-2" />
                {currentMoodData.label}
              </Button>
            </div>
          </div>

          {/* Mood Selector */}
          <AnimatePresence>
            {showMoodSelector && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="mt-4 p-4 bg-white/90 rounded-lg shadow-lg"
              >
                <p className="text-sm text-gray-600 mb-3">How are you feeling right now?</p>
                <div className="grid grid-cols-4 gap-2">
                  {moods.map((mood) => (
                    <Button
                      key={mood.type}
                      variant="outline"
                      size="sm"
                      onClick={() => handleMoodChange(mood.type)}
                      className={`${mood.bgColor} border-0 hover:bg-opacity-80 ${
                        currentMood === mood.type ? "ring-2 ring-purple-400" : ""
                      }`}
                    >
                      <mood.icon className="h-4 w-4 mr-2" />
                      {mood.label}
                    </Button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="space-y-6 mb-6">
          {messages.map((message, index) => (
            <motion.div
              key={message.id || index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div className={`max-w-[85%] ${message.role === "user" ? "order-2" : "order-1"}`}>
                <div className={`flex items-start gap-3 ${message.role === "user" ? "flex-row-reverse" : "flex-row"}`}>
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      message.role === "user"
                        ? "bg-gradient-to-r from-blue-500 to-cyan-500"
                        : `bg-gradient-to-r ${currentMoodData.color}`
                    }`}
                  >
                    {message.role === "user" ? (
                      <span className="text-white font-semibold text-sm">You</span>
                    ) : (
                      <Sparkles className="h-4 w-4 text-white" />
                    )}
                  </div>
                  <Card
                    className={`${
                      message.role === "user"
                        ? "bg-gradient-to-r from-blue-500 to-cyan-500 text-white"
                        : "bg-white/95 backdrop-blur-sm shadow-lg border-purple-100"
                    } border-0`}
                  >
                    <CardContent className="p-6">
                      <div className="whitespace-pre-wrap font-mono text-sm leading-relaxed">{message.content}</div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </motion.div>
          ))}
          {isLoading && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
              <div className="flex items-start gap-3">
                <div
                  className={`w-8 h-8 rounded-full bg-gradient-to-r ${currentMoodData.color} flex items-center justify-center`}
                >
                  <Sparkles className="h-4 w-4 text-white" />
                </div>
                <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-md">
                  <CardContent className="p-4">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div
                        className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.1s" }}
                      ></div>
                      <div
                        className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.2s" }}
                      ></div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </motion.div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Actions */}
        <div className="mb-6">
          <p className="text-sm text-gray-600 mb-3">Quick Actions:</p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {quickActions.map((action) => (
              <Button
                key={action.label}
                variant="outline"
                size="sm"
                onClick={() => handleQuickAction(action.prompt)}
                className="bg-white/70 hover:bg-white/90 border-white/30 text-left justify-start"
              >
                <action.icon className="h-4 w-4 mr-2" />
                {action.label}
              </Button>
            ))}
          </div>
        </div>

        {/* Chat Input */}
        <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg sticky bottom-4">
          <CardContent className="p-4">
            <form onSubmit={handleSubmit} className="flex gap-3">
              <Input
                value={input}
                onChange={handleInputChange}
                placeholder={`Tell ${chatbotName} how you're feeling or what you need...`}
                className="flex-1 border-0 bg-gray-50 focus:bg-white transition-colors"
                disabled={isLoading}
              />
              <Button
                type="submit"
                disabled={isLoading || !input.trim()}
                className={`bg-gradient-to-r ${currentMoodData.color} hover:opacity-90 text-white px-6`}
              >
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
