"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Loader2, CheckCircle, XCircle, Bug, Eye, EyeOff } from "lucide-react"

export default function DebugPanel() {
  const [isLoading, setIsLoading] = useState(false)
  const [debugResult, setDebugResult] = useState<any>(null)
  const [showDetails, setShowDetails] = useState(false)

  const runDebugTest = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/debug")
      const result = await response.json()
      setDebugResult(result)
    } catch (error) {
      setDebugResult({
        error: "Failed to run debug test",
        message: error instanceof Error ? error.message : "Unknown error",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const getStatusIcon = (status: string) => {
    return status === "success" ? (
      <CheckCircle className="h-4 w-4 text-green-600" />
    ) : (
      <XCircle className="h-4 w-4 text-red-600" />
    )
  }

  const getStatusBadge = (status: string) => {
    return <Badge variant={status === "success" ? "default" : "destructive"}>{status.toUpperCase()}</Badge>
  }

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bug className="h-5 w-5 text-blue-600" />
          Complete API Debug Test
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Button
            onClick={runDebugTest}
            disabled={isLoading}
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Running Tests...
              </>
            ) : (
              "🔍 Run Complete Debug Test"
            )}
          </Button>

          {debugResult && (
            <Button variant="outline" onClick={() => setShowDetails(!showDetails)}>
              {showDetails ? <EyeOff className="mr-2 h-4 w-4" /> : <Eye className="mr-2 h-4 w-4" />}
              {showDetails ? "Hide Details" : "Show Details"}
            </Button>
          )}
        </div>

        {debugResult && (
          <div className="space-y-6">
            {/* Environment Check */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-3 flex items-center gap-2">🔧 Environment Configuration</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="font-medium">OpenAI API Key:</p>
                  <p className={debugResult.environment?.OPENAI_API_KEY ? "text-green-600" : "text-red-600"}>
                    {debugResult.environment?.OPENAI_API_KEY ? "✅ Configured" : "❌ Missing"}
                  </p>
                  {showDetails && debugResult.environment?.OPENAI_KEY_PREVIEW && (
                    <p className="text-xs text-gray-500">{debugResult.environment.OPENAI_KEY_PREVIEW}</p>
                  )}
                </div>
                <div>
                  <p className="font-medium">Qloo API Key:</p>
                  <p className={debugResult.environment?.QLOO_API_KEY ? "text-green-600" : "text-red-600"}>
                    {debugResult.environment?.QLOO_API_KEY ? "✅ Configured" : "❌ Missing"}
                  </p>
                  {showDetails && debugResult.environment?.QLOO_KEY_PREVIEW && (
                    <p className="text-xs text-gray-500">{debugResult.environment.QLOO_KEY_PREVIEW}</p>
                  )}
                </div>
                <div>
                  <p className="font-medium">Qloo API URL:</p>
                  <p className="text-gray-700">{debugResult.environment?.QLOO_API_URL || "Not set"}</p>
                </div>
                <div>
                  <p className="font-medium">Environment:</p>
                  <p className="text-gray-700">{debugResult.environment?.NODE_ENV || "Not set"}</p>
                </div>
              </div>
            </div>

            {/* OpenAI Test */}
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                {getStatusIcon(debugResult.openai?.status)}🤖 OpenAI API Test
                {getStatusBadge(debugResult.openai?.status)}
              </h3>
              <p className="text-sm text-gray-700">{debugResult.openai?.message}</p>
            </div>

            {/* Qloo Test */}
            <div className="bg-purple-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                {getStatusIcon(debugResult.qloo?.status)}🎯 Qloo API Test
                {getStatusBadge(debugResult.qloo?.status)}
              </h3>
              <p className="text-sm text-gray-700 mb-2">{debugResult.qloo?.message}</p>

              {debugResult.qloo?.sampleData && debugResult.qloo.sampleData.length > 0 && (
                <div className="mt-3">
                  <p className="font-medium text-sm mb-2">Sample Recommendations:</p>
                  <div className="space-y-2">
                    {debugResult.qloo.sampleData.map((rec: any, index: number) => (
                      <div key={index} className="bg-white p-2 rounded text-xs">
                        <p className="font-medium">{rec.name}</p>
                        {rec.score && <p>Score: {rec.score}/10</p>}
                        {rec.explanation && <p className="italic text-gray-600">"{rec.explanation}"</p>}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Summary */}
            <div className="bg-gradient-to-r from-green-50 to-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">📋 Summary & Next Steps:</h3>
              <div className="text-sm space-y-1">
                {debugResult.openai?.status === "success" && debugResult.qloo?.status === "success" && (
                  <p className="text-green-700">✅ Both APIs are working! Your chat should work perfectly.</p>
                )}
                {debugResult.openai?.status === "error" && (
                  <p className="text-red-700">❌ OpenAI API issue - check your API key and quota</p>
                )}
                {debugResult.qloo?.status === "error" && (
                  <p className="text-red-700">❌ Qloo API issue - check your API key and URL</p>
                )}
                {debugResult.openai?.status === "success" && debugResult.qloo?.status === "error" && (
                  <p className="text-yellow-700">
                    ⚠️ OpenAI works, but Qloo doesn't - chat will work but without personalized recommendations
                  </p>
                )}
              </div>
            </div>

            {showDetails && (
              <div className="bg-gray-100 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">🔍 Raw Debug Data:</h3>
                <pre className="text-xs overflow-auto bg-white p-2 rounded">{JSON.stringify(debugResult, null, 2)}</pre>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
