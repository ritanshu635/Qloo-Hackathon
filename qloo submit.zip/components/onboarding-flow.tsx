"use client"

import React from "react"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Heart, Coffee, Shirt, Film, Plane, ArrowRight, ArrowLeft, Sparkles } from "lucide-react"
import type { UserPreferences } from "@/types/user"

interface OnboardingFlowProps {
  onComplete: (preferences: UserPreferences, chatbotName: string) => void
}

export default function OnboardingFlow({ onComplete }: OnboardingFlowProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [chatbotName, setChatbotName] = useState("")
  const [preferences, setPreferences] = useState<Partial<UserPreferences>>({})

  const steps = [
    {
      title: "Let's Get Personal",
      subtitle: "What would you like to name your AI companion?",
      icon: Heart,
    },
    {
      title: "Your Entertainment Taste",
      subtitle: "Tell us about your favorite movies, music, and shows",
      icon: Film,
    },
    {
      title: "Food & Lifestyle",
      subtitle: "What makes your taste buds happy?",
      icon: Coffee,
    },
    {
      title: "Style & Fashion",
      subtitle: "Describe your fashion sense and style preferences",
      icon: Shirt,
    },
    {
      title: "Travel & Places",
      subtitle: "Where do you love to go and explore?",
      icon: Plane,
    },
    {
      title: "Personality Match",
      subtitle: "How should your companion interact with you?",
      icon: Sparkles,
    },
  ]

  const musicGenres = [
    "Pop",
    "Rock",
    "Hip-Hop",
    "Classical",
    "Jazz",
    "Electronic",
    "Country",
    "R&B",
    "Indie",
    "Folk",
    "Reggae",
    "Blues",
    "Bollywood",
    "K-Pop",
    "Lo-fi",
    "Ambient",
  ]

  const movieGenres = [
    "Action",
    "Comedy",
    "Drama",
    "Horror",
    "Romance",
    "Sci-Fi",
    "Thriller",
    "Documentary",
    "Animation",
    "Fantasy",
    "Mystery",
    "Adventure",
    "Crime",
    "Biography",
    "Musical",
    "War",
  ]

  const foodTypes = [
    "Italian",
    "Chinese",
    "Indian",
    "Mexican",
    "Japanese",
    "Thai",
    "Mediterranean",
    "American",
    "French",
    "Korean",
    "Vietnamese",
    "Greek",
    "Spanish",
    "Lebanese",
    "Ethiopian",
    "Vegan",
  ]

  const fashionStyles = [
    "Casual",
    "Formal",
    "Bohemian",
    "Minimalist",
    "Vintage",
    "Streetwear",
    "Preppy",
    "Gothic",
    "Hipster",
    "Sporty",
    "Elegant",
    "Edgy",
    "Romantic",
    "Artsy",
    "Classic",
    "Trendy",
  ]

  const travelTypes = [
    "Beach",
    "Mountains",
    "Cities",
    "Countryside",
    "Historical Sites",
    "Adventure",
    "Luxury",
    "Budget",
    "Cultural",
    "Nature",
    "Nightlife",
    "Food Tours",
    "Art & Museums",
    "Spiritual",
  ]

  const personalityTypes = [
    "Witty & Sarcastic",
    "Gentle & Caring",
    "Energetic & Fun",
    "Calm & Wise",
    "Playful & Quirky",
    "Sophisticated & Elegant",
    "Adventurous & Bold",
    "Empathetic & Understanding",
  ]

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      // Complete onboarding
      const completePreferences: UserPreferences = {
        name: preferences.name || "",
        favoriteMovies: preferences.favoriteMovies || [],
        favoriteMusic: preferences.favoriteMusic || [],
        favoriteFood: preferences.favoriteFood || [],
        favoritePlaces: preferences.favoritePlaces || [],
        fashionStyle: preferences.fashionStyle || [],
        personalityType: preferences.personalityType || "Gentle & Caring",
        movieGenres: preferences.movieGenres || [],
        musicGenres: preferences.musicGenres || [],
        foodTypes: preferences.foodTypes || [],
        travelTypes: preferences.travelTypes || [],
        additionalInfo: preferences.additionalInfo || "",
      }
      onComplete(completePreferences, chatbotName)
    }
  }

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const toggleSelection = (category: keyof UserPreferences, item: string) => {
    const currentItems = (preferences[category] as string[]) || []
    const newItems = currentItems.includes(item) ? currentItems.filter((i) => i !== item) : [...currentItems, item]

    setPreferences((prev) => ({
      ...prev,
      [category]: newItems,
    }))
  }

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="h-10 w-10 text-white" />
              </div>
              <p className="text-gray-600">
                Choose a name that feels right for your AI companion. This will be how they introduce themselves to you!
              </p>
            </div>
            <div className="space-y-4">
              <Label htmlFor="chatbot-name" className="text-lg font-medium">
                Companion Name
              </Label>
              <Input
                id="chatbot-name"
                placeholder="e.g., Gogo, Alex, Luna, Sage..."
                value={chatbotName}
                onChange={(e) => setChatbotName(e.target.value)}
                className="text-lg p-4 border-2 focus:border-purple-400"
              />
              <div className="flex flex-wrap gap-2 mt-4">
                {["Gogo", "Luna", "Sage", "Nova", "Zara", "Echo"].map((name) => (
                  <Badge
                    key={name}
                    variant="outline"
                    className="cursor-pointer hover:bg-purple-100 hover:border-purple-400"
                    onClick={() => setChatbotName(name)}
                  >
                    {name}
                  </Badge>
                ))}
              </div>
            </div>
            <div className="space-y-4">
              <Label htmlFor="user-name" className="text-lg font-medium">
                Your Name
              </Label>
              <Input
                id="user-name"
                placeholder="What should your companion call you?"
                value={preferences.name || ""}
                onChange={(e) => setPreferences((prev) => ({ ...prev, name: e.target.value }))}
                className="text-lg p-4 border-2 focus:border-purple-400"
              />
            </div>
          </div>
        )

      case 1:
        return (
          <div className="space-y-8">
            <div className="space-y-4">
              <Label className="text-lg font-medium">Favorite Music Genres</Label>
              <div className="flex flex-wrap gap-2">
                {musicGenres.map((genre) => (
                  <Badge
                    key={genre}
                    variant={preferences.musicGenres?.includes(genre) ? "default" : "outline"}
                    className="cursor-pointer hover:bg-purple-100 hover:border-purple-400"
                    onClick={() => toggleSelection("musicGenres", genre)}
                  >
                    {genre}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <Label className="text-lg font-medium">Favorite Movie Genres</Label>
              <div className="flex flex-wrap gap-2">
                {movieGenres.map((genre) => (
                  <Badge
                    key={genre}
                    variant={preferences.movieGenres?.includes(genre) ? "default" : "outline"}
                    className="cursor-pointer hover:bg-purple-100 hover:border-purple-400"
                    onClick={() => toggleSelection("movieGenres", genre)}
                  >
                    {genre}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <Label htmlFor="favorite-movies" className="text-lg font-medium">
                Favorite Movies/Shows (Optional)
              </Label>
              <Textarea
                id="favorite-movies"
                placeholder="e.g., The Office, Spirited Away, Breaking Bad, Zindagi Na Milegi Dobara..."
                value={preferences.favoriteMovies?.join(", ") || ""}
                onChange={(e) =>
                  setPreferences((prev) => ({
                    ...prev,
                    favoriteMovies: e.target.value
                      .split(",")
                      .map((s) => s.trim())
                      .filter((s) => s),
                  }))
                }
                className="min-h-[100px] border-2 focus:border-purple-400"
              />
            </div>
          </div>
        )

      case 2:
        return (
          <div className="space-y-8">
            <div className="space-y-4">
              <Label className="text-lg font-medium">Favorite Cuisines</Label>
              <div className="flex flex-wrap gap-2">
                {foodTypes.map((food) => (
                  <Badge
                    key={food}
                    variant={preferences.foodTypes?.includes(food) ? "default" : "outline"}
                    className="cursor-pointer hover:bg-purple-100 hover:border-purple-400"
                    onClick={() => toggleSelection("foodTypes", food)}
                  >
                    {food}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <Label htmlFor="favorite-food" className="text-lg font-medium">
                Favorite Dishes (Optional)
              </Label>
              <Textarea
                id="favorite-food"
                placeholder="e.g., Pav Bhaji, Sushi, Pizza, Biryani, Tacos..."
                value={preferences.favoriteFood?.join(", ") || ""}
                onChange={(e) =>
                  setPreferences((prev) => ({
                    ...prev,
                    favoriteFood: e.target.value
                      .split(",")
                      .map((s) => s.trim())
                      .filter((s) => s),
                  }))
                }
                className="min-h-[100px] border-2 focus:border-purple-400"
              />
            </div>
          </div>
        )

      case 3:
        return (
          <div className="space-y-8">
            <div className="space-y-4">
              <Label className="text-lg font-medium">Fashion Style</Label>
              <div className="flex flex-wrap gap-2">
                {fashionStyles.map((style) => (
                  <Badge
                    key={style}
                    variant={preferences.fashionStyle?.includes(style) ? "default" : "outline"}
                    className="cursor-pointer hover:bg-purple-100 hover:border-purple-400"
                    onClick={() => toggleSelection("fashionStyle", style)}
                  >
                    {style}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        )

      case 4:
        return (
          <div className="space-y-8">
            <div className="space-y-4">
              <Label className="text-lg font-medium">Travel Preferences</Label>
              <div className="flex flex-wrap gap-2">
                {travelTypes.map((type) => (
                  <Badge
                    key={type}
                    variant={preferences.travelTypes?.includes(type) ? "default" : "outline"}
                    className="cursor-pointer hover:bg-purple-100 hover:border-purple-400"
                    onClick={() => toggleSelection("travelTypes", type)}
                  >
                    {type}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <Label htmlFor="favorite-places" className="text-lg font-medium">
                Favorite Destinations (Optional)
              </Label>
              <Textarea
                id="favorite-places"
                placeholder="e.g., Goa, Paris, Tokyo, New York, Himalayas..."
                value={preferences.favoritePlaces?.join(", ") || ""}
                onChange={(e) =>
                  setPreferences((prev) => ({
                    ...prev,
                    favoritePlaces: e.target.value
                      .split(",")
                      .map((s) => s.trim())
                      .filter((s) => s),
                  }))
                }
                className="min-h-[100px] border-2 focus:border-purple-400"
              />
            </div>
          </div>
        )

      case 5:
        return (
          <div className="space-y-8">
            <div className="space-y-4">
              <Label className="text-lg font-medium">Companion Personality</Label>
              <p className="text-gray-600 mb-4">How would you like your AI companion to interact with you?</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {personalityTypes.map((type) => (
                  <Card
                    key={type}
                    className={`cursor-pointer transition-all duration-200 ${
                      preferences.personalityType === type
                        ? "border-purple-400 bg-purple-50"
                        : "hover:border-purple-200 hover:bg-purple-25"
                    }`}
                    onClick={() => setPreferences((prev) => ({ ...prev, personalityType: type }))}
                  >
                    <CardContent className="p-4 text-center">
                      <span className="font-medium">{type}</span>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <Label htmlFor="additional-info" className="text-lg font-medium">
                Anything Else? (Optional)
              </Label>
              <Textarea
                id="additional-info"
                placeholder="Tell us anything else that would help your companion understand you better..."
                value={preferences.additionalInfo || ""}
                onChange={(e) => setPreferences((prev) => ({ ...prev, additionalInfo: e.target.value }))}
                className="min-h-[100px] border-2 focus:border-purple-400"
              />
            </div>
          </div>
        )

      default:
        return null
    }
  }

  const canProceed = () => {
    switch (currentStep) {
      case 0:
        return chatbotName.trim().length > 0
      default:
        return true
    }
  }

  const currentStepIcon = steps[currentStep].icon

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-gray-500">
              Step {currentStep + 1} of {steps.length}
            </span>
            <span className="text-sm text-gray-500">
              {Math.round(((currentStep + 1) / steps.length) * 100)}% Complete
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <motion.div
              className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="border-0 shadow-xl bg-white/80 backdrop-blur-sm">
              <CardHeader className="text-center pb-6">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  {React.createElement(currentStepIcon, { className: "h-8 w-8 text-white" })}
                </div>
                <CardTitle className="text-3xl font-bold text-gray-800">{steps[currentStep].title}</CardTitle>
                <p className="text-gray-600 text-lg">{steps[currentStep].subtitle}</p>
              </CardHeader>
              <CardContent className="px-8 pb-8">{renderStepContent()}</CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>

        {/* Navigation */}
        <div className="flex justify-between mt-8">
          <Button
            variant="outline"
            onClick={handleBack}
            disabled={currentStep === 0}
            className="px-6 py-3 bg-transparent"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <Button
            onClick={handleNext}
            disabled={!canProceed()}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 px-6 py-3"
          >
            {currentStep === steps.length - 1 ? "Complete Setup" : "Next"}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}
