"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Camera, X, ImageIcon } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import {
  Send,
  Frown,
  Meh,
  Heart,
  Zap,
  Coffee,
  Music,
  MapPin,
  Shirt,
  Film,
  ArrowLeft,
  Sparkles,
  Sun,
  Cloud,
  CloudRain,
  Moon,
} from "lucide-react"
import type { UserPreferences, MoodType, Message } from "@/types/user"

interface ChatInterfaceProps {
  userPreferences: UserPreferences
  chatbotName: string
  onBack: () => void
}

export default function ChatInterfacePure({ userPreferences, chatbotName, onBack }: ChatInterfaceProps) {
  const [currentMood, setCurrentMood] = useState<MoodType>("neutral")
  const [showMoodSelector, setShowMoodSelector] = useState(false)
  const [uiTheme, setUiTheme] = useState("default")
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: `✨ **Hey ${userPreferences.name || "there"}!** I'm ${chatbotName}, your personal companion powered by Qloo's cultural intelligence! 🎯

🌟 **I've learned about your preferences:**
${userPreferences.musicGenres?.length ? `🎵 **Music:** ${userPreferences.musicGenres.slice(0, 3).join(", ")}` : ""}
${userPreferences.movieGenres?.length ? `🎬 **Movies:** ${userPreferences.movieGenres.slice(0, 3).join(", ")}` : ""}
${userPreferences.foodTypes?.length ? `🍽️ **Food:** ${userPreferences.foodTypes.slice(0, 3).join(", ")}` : ""}
${userPreferences.fashionStyle?.length ? `👗 **Style:** ${userPreferences.fashionStyle.slice(0, 2).join(", ")}` : ""}

💫 **How are you feeling today?** I'm here to chat, recommend, and understand exactly what you need! ✨`,
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const [selectedImage, setSelectedImage] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [isAnalyzingImage, setIsAnalyzingImage] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const moods = [
    {
      type: "happy" as MoodType,
      icon: Sun,
      label: "Happy",
      color: "from-yellow-400 to-orange-400",
      bgColor: "bg-yellow-50",
    },
    {
      type: "sad" as MoodType,
      icon: CloudRain,
      label: "Sad",
      color: "from-blue-400 to-indigo-400",
      bgColor: "bg-blue-50",
    },
    {
      type: "excited" as MoodType,
      icon: Zap,
      label: "Excited",
      color: "from-pink-400 to-red-400",
      bgColor: "bg-pink-50",
    },
    {
      type: "calm" as MoodType,
      icon: Cloud,
      label: "Calm",
      color: "from-green-400 to-teal-400",
      bgColor: "bg-green-50",
    },
    {
      type: "anxious" as MoodType,
      icon: Frown,
      label: "Anxious",
      color: "from-purple-400 to-indigo-400",
      bgColor: "bg-purple-50",
    },
    {
      type: "nostalgic" as MoodType,
      icon: Moon,
      label: "Nostalgic",
      color: "from-indigo-400 to-purple-400",
      bgColor: "bg-indigo-50",
    },
    {
      type: "neutral" as MoodType,
      icon: Meh,
      label: "Neutral",
      color: "from-gray-400 to-gray-500",
      bgColor: "bg-gray-50",
    },
    {
      type: "romantic" as MoodType,
      icon: Heart,
      label: "Romantic",
      color: "from-rose-400 to-pink-400",
      bgColor: "bg-rose-50",
    },
  ]

  const currentMoodData = moods.find((m) => m.type === currentMood) || moods[6]

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  useEffect(() => {
    // Change UI theme based on mood
    const moodThemes = {
      happy: "from-yellow-50 via-orange-50 to-pink-50",
      sad: "from-blue-50 via-indigo-50 to-purple-50",
      excited: "from-pink-50 via-red-50 to-orange-50",
      calm: "from-green-50 via-teal-50 to-blue-50",
      anxious: "from-purple-50 via-indigo-50 to-blue-50",
      nostalgic: "from-indigo-50 via-purple-50 to-pink-50",
      neutral: "from-gray-50 via-slate-50 to-zinc-50",
      romantic: "from-rose-50 via-pink-50 to-red-50",
    }
    setUiTheme(moodThemes[currentMood])
  }, [currentMood])

  const quickActions = [
    { icon: Music, label: "Music Rec", prompt: "I want to listen to some music that matches my current mood" },
    { icon: Coffee, label: "Food Spot", prompt: "Suggest a place to eat based on how I'm feeling" },
    { icon: Film, label: "Movie Night", prompt: "Recommend a movie for my current mood" },
    { icon: Shirt, label: "Outfit Ideas", prompt: "Help me choose what to wear today" },
    { icon: MapPin, label: "Go Somewhere", prompt: "I want to go somewhere that fits my vibe" },
    { icon: Heart, label: "Cheer Me Up", prompt: "I need some emotional support and comfort" },
  ]

  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file && file.type.startsWith("image/")) {
      setSelectedImage(file)
      const reader = new FileReader()
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const removeSelectedImage = () => {
    setSelectedImage(null)
    setImagePreview(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleImageAnalysis = async () => {
    if (!selectedImage) return

    setIsAnalyzingImage(true)

    try {
      const reader = new FileReader()
      reader.onload = async (e) => {
        const base64Image = e.target?.result as string

        const imageMessage: Message = {
          id: Date.now().toString(),
          role: "user",
          content: `🖼️ **Analyzing uploaded image...** 

*[Image uploaded: ${selectedImage.name}]*`,
          timestamp: new Date(),
        }

        setMessages((prev) => [...prev, imageMessage])
        removeSelectedImage()

        try {
          const response = await fetch("/api/analyze-image", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              image: base64Image,
              userPreferences,
              currentMood,
              chatbotName,
            }),
          })

          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`)
          }

          const reader = response.body?.getReader()
          if (!reader) {
            throw new Error("No response body")
          }

          let assistantContent = ""
          const decoder = new TextDecoder()

          while (true) {
            const { done, value } = await reader.read()
            if (done) break

            const chunk = decoder.decode(value)
            const lines = chunk.split("\n")
            for (const line of lines) {
              if (line.startsWith("0:")) {
                try {
                  const data = JSON.parse(line.slice(2))
                  if (data.type === "text") {
                    assistantContent += data.text
                  }
                } catch (e) {
                  console.error("Failed to parse chunk:", e)
                }
              }
            }
          }

          if (assistantContent) {
            const assistantMessage: Message = {
              id: Date.now().toString(),
              role: "assistant",
              content: assistantContent,
              timestamp: new Date(),
            }
            setMessages((prev) => [...prev, assistantMessage])
          }
        } catch (error) {
          console.error("Image analysis error:", error)
          const errorMessage: Message = {
            id: Date.now().toString(),
            role: "assistant",
            content: "Sorry, I couldn't analyze that image. Please try again! 😊",
            timestamp: new Date(),
          }
          setMessages((prev) => [...prev, errorMessage])
        }
      }
      reader.readAsDataURL(selectedImage)
    } catch (error) {
      console.error("Image processing error:", error)
    } finally {
      setIsAnalyzingImage(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      console.log("🚀 Sending request to /api/chat")

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [...messages, userMessage],
          userPreferences,
          currentMood,
          chatbotName,
        }),
      })

      console.log("📡 Response status:", response.status)

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const reader = response.body?.getReader()
      if (!reader) {
        throw new Error("No response body")
      }

      let assistantContent = ""
      const decoder = new TextDecoder()

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        const chunk = decoder.decode(value)
        console.log("📦 Received chunk:", chunk)

        // Parse AI SDK streaming format
        const lines = chunk.split("\n")
        for (const line of lines) {
          if (line.startsWith("0:")) {
            try {
              const data = JSON.parse(line.slice(2))
              if (data.type === "text") {
                assistantContent += data.text
              }
            } catch (e) {
              console.error("Failed to parse chunk:", e)
            }
          }
        }
      }

      console.log("✅ Final assistant content:", assistantContent.substring(0, 200) + "...")

      if (assistantContent) {
        const assistantMessage: Message = {
          id: Date.now().toString(),
          role: "assistant",
          content: assistantContent,
          timestamp: new Date(),
        }
        setMessages((prev) => [...prev, assistantMessage])
      }
    } catch (error) {
      console.error("💥 Chat error:", error)
      const errorMessage: Message = {
        id: Date.now().toString(),
        role: "assistant",
        content: "Sorry, I'm having trouble getting recommendations right now. Please try again! 😊",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const handleQuickAction = (prompt: string) => {
    setInput(prompt)
  }

  const handleMoodChange = (mood: MoodType) => {
    setCurrentMood(mood)
    setShowMoodSelector(false)
    setInput(`I'm feeling ${mood} right now.`)
  }

  // Function to render markdown-style content
  const renderMessageContent = (content: string) => {
    return content
      .replace(/\*\*(.*?)\*\*/g, '<strong class="text-purple-700 font-semibold">$1</strong>')
      .replace(/^## (.*$)/gm, '<h2 class="text-xl font-bold text-purple-800 mb-3 mt-6">$1</h2>')
      .replace(/^# (.*$)/gm, '<h1 class="text-2xl font-bold text-purple-900 mb-4 mt-8">$1</h1>')
      .replace(/^\* (.*$)/gm, '<li class="ml-4 mb-1">• $1</li>')
      .replace(/^• (.*$)/gm, '<li class="ml-4 mb-1 text-gray-700">• $1</li>')
      .replace(/^---$/gm, '<hr class="my-6 border-purple-200" />')
      .replace(/\n/g, "<br />")
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br ${uiTheme} transition-all duration-1000`}>
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white/80 backdrop-blur-md border-b border-white/20 shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={onBack} className="hover:bg-white/50">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
              <div className="flex items-center gap-3">
                <div
                  className={`w-10 h-10 rounded-full bg-gradient-to-r ${currentMoodData.color} flex items-center justify-center`}
                >
                  <Sparkles className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h1 className="font-bold text-lg text-gray-800">{chatbotName}</h1>
                  <p className="text-sm text-gray-600">Powered by Qloo API</p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowMoodSelector(!showMoodSelector)}
                className={`${currentMoodData.bgColor} border-0 hover:bg-opacity-80`}
              >
                <currentMoodData.icon className="h-4 w-4 mr-2" />
                {currentMoodData.label}
              </Button>
            </div>
          </div>

          {/* Mood Selector */}
          <AnimatePresence>
            {showMoodSelector && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="mt-4 p-4 bg-white/90 rounded-lg shadow-lg"
              >
                <p className="text-sm text-gray-600 mb-3">How are you feeling right now?</p>
                <div className="grid grid-cols-4 gap-2">
                  {moods.map((mood) => (
                    <Button
                      key={mood.type}
                      variant="outline"
                      size="sm"
                      onClick={() => handleMoodChange(mood.type)}
                      className={`${mood.bgColor} border-0 hover:bg-opacity-80 ${
                        currentMood === mood.type ? "ring-2 ring-purple-400" : ""
                      }`}
                    >
                      <mood.icon className="h-4 w-4 mr-2" />
                      {mood.label}
                    </Button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="space-y-6 mb-6">
          {messages.map((message, index) => (
            <motion.div
              key={message.id || index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div className={`max-w-[85%] ${message.role === "user" ? "order-2" : "order-1"}`}>
                <div className={`flex items-start gap-3 ${message.role === "user" ? "flex-row-reverse" : "flex-row"}`}>
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      message.role === "user"
                        ? "bg-gradient-to-r from-blue-500 to-cyan-500"
                        : `bg-gradient-to-r ${currentMoodData.color}`
                    }`}
                  >
                    {message.role === "user" ? (
                      <span className="text-white font-semibold text-sm">You</span>
                    ) : (
                      <Sparkles className="h-4 w-4 text-white" />
                    )}
                  </div>
                  <Card
                    className={`${
                      message.role === "user"
                        ? "bg-gradient-to-r from-blue-500 to-cyan-500 text-white"
                        : "bg-white/95 backdrop-blur-sm shadow-lg border-purple-100"
                    } border-0`}
                  >
                    <CardContent className="p-6">
                      <div
                        className={`prose prose-sm max-w-none leading-relaxed ${
                          message.role === "user"
                            ? "text-white"
                            : "text-gray-800 [&_strong]:text-purple-700 [&_h2]:text-purple-800 [&_h1]:text-purple-900 [&_li]:text-gray-700"
                        }`}
                        dangerouslySetInnerHTML={{
                          __html: renderMessageContent(message.content),
                        }}
                      />
                    </CardContent>
                  </Card>
                </div>
              </div>
            </motion.div>
          ))}
          {isLoading && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
              <div className="flex items-start gap-3">
                <div
                  className={`w-8 h-8 rounded-full bg-gradient-to-r ${currentMoodData.color} flex items-center justify-center`}
                >
                  <Sparkles className="h-4 w-4 text-white" />
                </div>
                <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-md">
                  <CardContent className="p-4">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div
                        className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.1s" }}
                      ></div>
                      <div
                        className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.2s" }}
                      ></div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </motion.div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Actions */}
        <div className="mb-6">
          <p className="text-sm text-gray-600 mb-3">Quick Actions:</p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {quickActions.map((action) => (
              <Button
                key={action.label}
                variant="outline"
                size="sm"
                onClick={() => handleQuickAction(action.prompt)}
                className="bg-white/70 hover:bg-white/90 border-white/30 text-left justify-start"
              >
                <action.icon className="h-4 w-4 mr-2" />
                {action.label}
              </Button>
            ))}
          </div>
        </div>

        {/* Image Upload Section */}
        {(selectedImage || imagePreview) && (
          <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg mb-4">
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                {imagePreview && (
                  <div className="relative">
                    <img
                      src={imagePreview || "/placeholder.svg"}
                      alt="Selected"
                      className="w-20 h-20 object-cover rounded-lg"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={removeSelectedImage}
                      className="absolute -top-2 -right-2 w-6 h-6 p-0 rounded-full bg-red-500 text-white hover:bg-red-600"
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                )}
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-700">Ready to analyze: {selectedImage?.name}</p>
                  <p className="text-xs text-gray-500">I'll describe what I see and find similar recommendations!</p>
                </div>
                <Button
                  onClick={handleImageAnalysis}
                  disabled={isAnalyzingImage}
                  className={`bg-gradient-to-r ${currentMoodData.color} hover:opacity-90 text-white px-4`}
                >
                  {isAnalyzingImage ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Camera className="h-4 w-4 mr-2" />
                      Analyze Image
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Hidden file input */}
        <input ref={fileInputRef} type="file" accept="image/*" onChange={handleImageSelect} className="hidden" />

        {/* Chat Input */}
        <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg sticky bottom-4">
          <CardContent className="p-4">
            <form onSubmit={handleSubmit} className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                className="px-3 bg-gray-50 hover:bg-gray-100 border-gray-200"
                disabled={isLoading || isAnalyzingImage}
              >
                <ImageIcon className="h-4 w-4" />
              </Button>
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={`Tell ${chatbotName} how you're feeling or upload an image...`}
                className="flex-1 border-0 bg-gray-50 focus:bg-white transition-colors"
                disabled={isLoading || isAnalyzingImage}
              />
              <Button
                type="submit"
                disabled={isLoading || !input.trim() || isAnalyzingImage}
                className={`bg-gradient-to-r ${currentMoodData.color} hover:opacity-90 text-white px-6`}
              >
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
