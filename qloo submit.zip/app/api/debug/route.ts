export async function GET() {
  try {
    // Check environment variables
    const envCheck = {
      OPENAI_API_KEY: !!process.env.OPENAI_API_KEY,
      OPENAI_KEY_PREVIEW: process.env.OPENAI_API_KEY ? `${process.env.OPENAI_API_KEY.substring(0, 15)}...` : "Not set",
      QLOO_API_KEY: !!process.env.QLOO_API_KEY,
      QLOO_KEY_PREVIEW: process.env.QLOO_API_KEY ? `${process.env.QLOO_API_KEY.substring(0, 15)}...` : "Not set",
      QLOO_API_URL: process.env.QLOO_API_URL || "Not set",
      NODE_ENV: process.env.NODE_ENV || "Not set",
    }

    // Test OpenAI API
    let openaiTest = { status: "error", message: "Not tested" }
    try {
      const openaiResponse = await fetch("https://api.openai.com/v1/models", {
        headers: {
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        },
      })

      if (openaiResponse.ok) {
        openaiTest = { status: "success", message: "OpenAI API key is valid" }
      } else {
        const errorText = await openaiResponse.text()
        openaiTest = { status: "error", message: `OpenAI API error: ${openaiResponse.status} - ${errorText}` }
      }
    } catch (error) {
      openaiTest = { status: "error", message: `OpenAI API connection failed: ${error}` }
    }

    // Test Qloo API using the correct format from documentation
    let qlooTest = { status: "error", message: "Not tested" }
    try {
      // Test the /v2/insights endpoint with proper parameters
      const qlooUrl = `${process.env.QLOO_API_URL}/v2/insights?filter.type=urn:entity:movie&limit=3`

      console.log(`Testing Qloo API: ${qlooUrl}`)
      console.log(`Using API Key: ${process.env.QLOO_API_KEY?.substring(0, 15)}...`)

      const qlooResponse = await fetch(qlooUrl, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "X-Api-Key": process.env.QLOO_API_KEY || "", // Using X-Api-Key as per documentation
        },
      })

      console.log(`Qloo Response Status: ${qlooResponse.status}`)

      if (qlooResponse.ok) {
        const qlooData = await qlooResponse.json()
        console.log(`Qloo Response Data:`, qlooData)

        qlooTest = {
          status: "success",
          message: "Qloo API key is valid and working!",
          sampleData: qlooData.results?.entities?.slice(0, 2) || [],
          fullResponse: qlooData,
        }
      } else {
        const errorText = await qlooResponse.text()
        console.error(`Qloo Error Response:`, errorText)
        qlooTest = { status: "error", message: `Qloo API error: ${qlooResponse.status} - ${errorText}` }
      }
    } catch (error) {
      console.error(`Qloo API Test Error:`, error)
      qlooTest = { status: "error", message: `Qloo API connection failed: ${error}` }
    }

    return Response.json({
      timestamp: new Date().toISOString(),
      environment: envCheck,
      openai: openaiTest,
      qloo: qlooTest,
    })
  } catch (error) {
    return Response.json({
      error: "Debug endpoint failed",
      message: error instanceof Error ? error.message : "Unknown error",
    })
  }
}
