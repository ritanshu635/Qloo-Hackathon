import { qlooService, type QlooEntity } from "@/lib/qloo-service"
import type { UserPreferences, MoodType } from "@/types/user"

export const maxDuration = 30

export async function POST(req: Request) {
  console.log("🚀 Chat API called - DIRECT QLOO PROMPT")

  try {
    const body = await req.json()
    console.log("📝 Request body:", JSON.stringify(body, null, 2))

    const { messages, userPreferences, currentMood, chatbotName } = body

    if (!messages || !Array.isArray(messages)) {
      console.error("❌ Invalid messages format")
      return new Response("Invalid messages format", { status: 400 })
    }

    // Check ONLY Qloo API key
    if (!process.env.QLOO_API_KEY) {
      console.error("⚠️ Qloo API key missing")
      return new Response("Qloo API key not configured", { status: 500 })
    }

    console.log("🔑 Qloo API Key:", process.env.QLOO_API_KEY ? "✅ Present" : "❌ Missing")

    // Get the last user message - this is the EXACT prompt we'll send to Qloo
    const lastUserMessage = messages[messages.length - 1]?.content || ""
    console.log("💬 User prompt to send to Qloo:", lastUserMessage)

    // Check if this is a general greeting or if we should get recommendations
    const isGeneralChat =
      lastUserMessage.toLowerCase().includes("hello") ||
      lastUserMessage.toLowerCase().includes("hi") ||
      lastUserMessage.toLowerCase().includes("how are you") ||
      lastUserMessage.length < 10

    let qlooRecommendations: QlooEntity[] = []
    let recommendationType = "direct-qloo"

    if (!isGeneralChat) {
      console.log("🎯 Sending EXACT user prompt to Qloo API...")

      // Send the user's exact prompt directly to Qloo
      qlooRecommendations = await qlooService.getDirectRecommendations(lastUserMessage)

      console.log(`📊 Got ${qlooRecommendations.length} direct Qloo recommendations`)
    } else {
      recommendationType = "general"
      console.log("💬 General chat response")
    }

    // Create response based on Qloo's direct results
    const qlooResponse = createDirectQlooResponse(
      userPreferences,
      currentMood || "neutral",
      chatbotName || "Gogo",
      qlooRecommendations,
      recommendationType,
      lastUserMessage,
    )

    console.log("✅ Direct Qloo response generated successfully")
    console.log("📤 Sending to frontend:", qlooResponse.substring(0, 200) + "...")

    // Return ONLY Qloo data in AI SDK compatible format
    const encoder = new TextEncoder()
    const stream = new ReadableStream({
      start(controller) {
        // Send the response in AI SDK format
        controller.enqueue(encoder.encode(`0:${JSON.stringify({ type: "text", text: qlooResponse })}\n`))
        controller.enqueue(encoder.encode(`d:\n`))
        controller.close()
        console.log("✅ Stream sent to frontend")
      },
    })

    return new Response(stream, {
      status: 200,
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "x-vercel-ai-data-stream": "v1",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      },
    })
  } catch (error) {
    console.error("💥 Chat API Error:", error)

    // Return error in AI SDK format
    const encoder = new TextEncoder()
    const errorStream = new ReadableStream({
      start(controller) {
        controller.enqueue(
          encoder.encode(
            `0:${JSON.stringify({ type: "text", text: "Sorry, I'm having trouble getting recommendations right now. Please try again! 😊" })}\n`,
          ),
        )
        controller.enqueue(encoder.encode(`d:\n`))
        controller.close()
      },
    })

    return new Response(errorStream, {
      status: 200,
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "x-vercel-ai-data-stream": "v1",
      },
    })
  }
}

function createDirectQlooResponse(
  userPreferences: UserPreferences | undefined,
  currentMood: MoodType,
  chatbotName: string,
  qlooRecommendations: QlooEntity[],
  recommendationType: string,
  userPrompt: string,
): string {
  const userName = userPreferences?.name || "there"

  // Handle general chat
  if (recommendationType === "general") {
    return `✨ **Hey ${userName}!** I'm ${chatbotName}, powered by Qloo's cultural intelligence! 🎯

🌟 **I can help you discover:**
🎵 **Music** that matches your vibe
🎬 **Movies** perfect for your mood  
🍽️ **Restaurants** you'll absolutely love
👗 **Fashion** that fits your style
✈️ **Travel** destinations made for you

💫 Just tell me exactly what you're looking for! I'll pass your request directly to Qloo for the most accurate results.

**Try asking:**
• "Show me brunch restaurants in NYC that are vegan, wheelchair accessible, and have at least 4.5 stars"
• "Find thriller movies from 2023 with great reviews"
• "Recommend trendy fashion brands in Paris"
• "Suggest upbeat music for working out"`
  }

  // Handle no recommendations found
  if (qlooRecommendations.length === 0) {
    return `🤔 **Hey ${userName}!** I sent your request "${userPrompt}" directly to Qloo, but couldn't find specific recommendations right now. 

This could be because:
• The query is too specific or niche
• The location/criteria combination has limited results
• There might be a temporary API issue

🎯 **Try rephrasing your request or asking for:**
• "Restaurants in NYC with good reviews"
• "Popular movies this year"
• "Trending music artists"
• "Fashion brands in [city]"
• "Travel destinations for [mood/activity]"`
  }

  const moodEmojis = {
    happy: "😊",
    sad: "🤗",
    excited: "🚀",
    calm: "😌",
    anxious: "💙",
    nostalgic: "✨",
    neutral: "👍",
    romantic: "💕",
  }

  let response = `🎯 **Hey ${userName}!** ${moodEmojis[currentMood]} Here are Qloo's direct results for: **"${userPrompt}"**

`

  // Display results exactly as Qloo returned them
  qlooRecommendations.slice(0, 8).forEach((rec, index) => {
    const popularity = rec.properties.popularity ? Math.round(rec.properties.popularity * 100) : null
    const affinityScore = rec.query?.affinity ? (rec.query.affinity * 100).toFixed(1) : null
    const description = rec.properties.description || "Recommended by Qloo's cultural intelligence"
    const releaseYear = rec.properties.release_year || ""
    const duration = rec.properties.duration || ""
    const rating = rec.properties.content_rating || ""

    response += `## ${index + 1}. **${rec.name}** ${releaseYear ? `*(${releaseYear})*` : ""}

📖 **Description:** ${description.substring(0, 300)}${description.length > 300 ? "..." : ""}

`

    // Show Qloo's scoring data
    if (affinityScore) {
      response += `🎯 **Qloo Affinity Score:** ${affinityScore}% • `
    }

    if (popularity) {
      response += `⭐ **Popularity Score:** ${popularity}% • `
    }

    if (rating) {
      response += `🎬 **Rating:** ${rating} • `
    }

    if (duration) {
      response += `⏱️ **Duration:** ${duration} min`
    }

    response += `

🔍 **Entity Type:** ${rec.subtype?.replace("urn:entity:", "") || rec.type?.replace("urn:entity:", "") || "Unknown"}

`

    // Show cultural tags if available
    if (rec.properties.tags && rec.properties.tags.length > 0) {
      const topTags = rec.properties.tags
        .slice(0, 4)
        .map((t) => t.name)
        .join(" • ")
      response += `🏷️ **Cultural Tags:** ${topTags}

`
    }

    // Show external links if available
    if (rec.properties.external) {
      const externalLinks = []
      if (rec.properties.external.imdb) externalLinks.push(`[IMDB](${rec.properties.external.imdb})`)
      if (rec.properties.external.spotify) externalLinks.push(`[Spotify](${rec.properties.external.spotify})`)
      if (rec.properties.external.booking) externalLinks.push(`[Booking](${rec.properties.external.booking})`)

      if (externalLinks.length > 0) {
        response += `🔗 **Links:** ${externalLinks.join(" • ")}

`
      }
    }

    response += `---

`
  })

  response += `🎉 **Results powered by Qloo's cultural intelligence!** These recommendations are based on your exact query.

💡 **Pro Tip:** The more specific your request, the more targeted Qloo's recommendations will be!`

  return response
}
