import { qlooService, type QlooEntity } from "@/lib/qloo-service"
import type { UserPreferences, MoodType } from "@/types/user"

export const maxDuration = 30

export async function POST(req: Request) {
  console.log("🖼️ Image Analysis API called")

  try {
    const body = await req.json()
    console.log("📝 Request received with image data")

    const { image, userPreferences, currentMood, chatbotName } = body

    if (!image) {
      console.error("❌ No image provided")
      return new Response("No image provided", { status: 400 })
    }

    // Check API keys
    if (!process.env.OPENAI_API_KEY) {
      console.error("⚠️ OpenAI API key missing")
      return new Response("OpenAI API key not configured", { status: 500 })
    }

    if (!process.env.QLOO_API_KEY) {
      console.error("⚠️ Qloo API key missing")
      return new Response("Qloo API key not configured", { status: 500 })
    }

    console.log("🔑 API Keys:", {
      openai: process.env.OPENAI_API_KEY ? "✅ Present" : "❌ Missing",
      qloo: process.env.QLOO_API_KEY ? "✅ Present" : "❌ Missing",
    })

    // Step 1: Send image to GPT-4o Mini for description
    console.log("🤖 Sending image to GPT-4o Mini...")

    const openaiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: `Analyze this image and describe it in detail for finding similar recommendations. Focus on:

1. **Type**: What is this? (restaurant, cafe, clothing, place, etc.)
2. **Style & Vibe**: Describe the aesthetic, ambiance, mood
3. **Key Features**: Notable characteristics, colors, design elements
4. **Category**: Specific category for recommendations (e.g., "casual dining", "vintage fashion", "modern architecture")

Provide a detailed description that would help find similar places, items, or experiences.`,
              },
              {
                type: "image_url",
                image_url: {
                  url: image,
                },
              },
            ],
          },
        ],
        max_tokens: 500,
      }),
    })

    console.log("📡 OpenAI Response status:", openaiResponse.status)

    if (!openaiResponse.ok) {
      const errorText = await openaiResponse.text()
      console.error("❌ OpenAI API error:", errorText)
      throw new Error(`OpenAI API error: ${openaiResponse.status} - ${errorText}`)
    }

    const openaiData = await openaiResponse.json()
    const imageDescription = openaiData.choices[0]?.message?.content || "Could not analyze image"

    console.log("✅ GPT-4o Mini description:", imageDescription.substring(0, 200) + "...")

    // Step 2: Send description to Qloo for similar recommendations
    console.log("🎯 Sending description to Qloo...")

    const qlooRecommendations = await qlooService.getDirectRecommendations(imageDescription)

    console.log(`📊 Got ${qlooRecommendations.length} Qloo recommendations`)

    // Step 3: Create combined response
    const combinedResponse = createImageAnalysisResponse(
      userPreferences,
      currentMood || "neutral",
      chatbotName || "Gogo",
      imageDescription,
      qlooRecommendations,
    )

    console.log("✅ Combined response generated successfully")

    // Return in AI SDK compatible format
    const encoder = new TextEncoder()
    const stream = new ReadableStream({
      start(controller) {
        controller.enqueue(encoder.encode(`0:${JSON.stringify({ type: "text", text: combinedResponse })}\n`))
        controller.enqueue(encoder.encode(`d:\n`))
        controller.close()
        console.log("✅ Stream sent to frontend")
      },
    })

    return new Response(stream, {
      status: 200,
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "x-vercel-ai-data-stream": "v1",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      },
    })
  } catch (error) {
    console.error("💥 Image Analysis Error:", error)

    // Return error in AI SDK format
    const encoder = new TextEncoder()
    const errorStream = new ReadableStream({
      start(controller) {
        controller.enqueue(
          encoder.encode(
            `0:${JSON.stringify({ type: "text", text: "Sorry, I couldn't analyze that image. Please try again! 😊" })}\n`,
          ),
        )
        controller.enqueue(encoder.encode(`d:\n`))
        controller.close()
      },
    })

    return new Response(errorStream, {
      status: 200,
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "x-vercel-ai-data-stream": "v1",
      },
    })
  }
}

function createImageAnalysisResponse(
  userPreferences: UserPreferences | undefined,
  currentMood: MoodType,
  chatbotName: string,
  gptDescription: string,
  qlooRecommendations: QlooEntity[],
): string {
  const userName = userPreferences?.name || "there"

  const moodEmojis = {
    happy: "😊",
    sad: "🤗",
    excited: "🚀",
    calm: "😌",
    anxious: "💙",
    nostalgic: "✨",
    neutral: "👍",
    romantic: "💕",
  }

  let response = `🖼️ **Hey ${userName}!** ${moodEmojis[currentMood]} I've analyzed your image using GPT-4o Mini and found similar recommendations through Qloo!

## 🤖 **GPT-4o Mini Analysis:**

${gptDescription}

---

`

  if (qlooRecommendations.length === 0) {
    response += `🤔 **Qloo couldn't find specific matches** for this image right now, but the analysis above gives you great insights!

💡 **Try uploading:**
• Restaurant/cafe images for similar dining spots
• Fashion items for similar brands
• Travel destinations for similar places
• Architecture for similar venues`

    return response
  }

  response += `## 🎯 **Similar Recommendations from Qloo:**

Based on the image analysis, here are ${qlooRecommendations.length} similar recommendations:

`

  // Display Qloo recommendations
  qlooRecommendations.slice(0, 6).forEach((rec, index) => {
    const popularity = rec.properties.popularity ? Math.round(rec.properties.popularity * 100) : null
    const affinityScore = rec.query?.affinity ? (rec.query.affinity * 100).toFixed(1) : null
    const description = rec.properties.description || "A great match based on your image!"
    const releaseYear = rec.properties.release_year || ""

    response += `### ${index + 1}. **${rec.name}** ${releaseYear ? `*(${releaseYear})*` : ""}

📖 **Description:** ${description.substring(0, 250)}${description.length > 250 ? "..." : ""}

`

    if (affinityScore) {
      response += `🎯 **Match Score:** ${affinityScore}% • `
    }

    if (popularity) {
      response += `⭐ **Popularity:** ${popularity}%`
    }

    response += `

🔍 **Type:** ${rec.subtype?.replace("urn:entity:", "") || rec.type?.replace("urn:entity:", "") || "Similar"}

`

    if (rec.properties.tags && rec.properties.tags.length > 0) {
      const topTags = rec.properties.tags
        .slice(0, 3)
        .map((t) => t.name)
        .join(" • ")
      response += `🏷️ **Tags:** ${topTags}

`
    }

    response += `---

`
  })

  response += `🎉 **Perfect matches found!** These recommendations are based on GPT-4o Mini's visual analysis combined with Qloo's cultural intelligence.

💡 **Pro Tip:** Upload more images to discover similar places, brands, or experiences!`

  return response
}
