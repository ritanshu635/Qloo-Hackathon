import { qlooService } from "@/lib/qloo-service"

export async function GET() {
  try {
    // Test the Qloo API connection with simple taste inputs
    const testRecommendations = await qlooService.getRecommendations(["pop music", "indie rock", "happy songs"], {
      numResults: 3,
    })

    return Response.json({
      status: "success",
      message: "Qloo API connection successful!",
      sampleRecommendations: testRecommendations,
      apiUrl: process.env.QLOO_API_URL,
      hasApiKey: !!process.env.QLOO_API_KEY,
      apiKeyPreview: process.env.QLOO_API_KEY ? `${process.env.QLOO_API_KEY.substring(0, 10)}...` : "Not set",
    })
  } catch (error) {
    return Response.json({
      status: "error",
      message: "Qloo API connection failed",
      error: error instanceof Error ? error.message : "Unknown error",
      apiUrl: process.env.QLOO_API_URL,
      hasApiKey: !!process.env.QLOO_API_KEY,
      apiKeyPreview: process.env.QLOO_API_KEY ? `${process.env.QLOO_API_KEY.substring(0, 10)}...` : "Not set",
    })
  }
}
