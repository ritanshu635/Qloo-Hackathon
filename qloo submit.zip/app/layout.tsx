import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Gogo - Your Emotion + Taste Companion AI",
  description:
    "The world's first AI companion that understands both your emotions and cultural taste. Built for the Qloo Hackathon 2025.",
  keywords: "AI companion, emotional intelligence, taste preferences, Qloo, OpenAI, personalized recommendations",
  authors: [{ name: "Gogo Team" }],
  openGraph: {
    title: "Gogo - Your Emotion + Taste Companion AI",
    description: "Meet your perfect AI companion that understands your emotions and cultural taste",
    type: "website",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  )
}
