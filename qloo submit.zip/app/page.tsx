"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import LandingPage from "@/components/landing-page"
import OnboardingFlow from "@/components/onboarding-flow"
import ChatInterfacePure from "@/components/chat-interface-pure"
import type { UserPreferences } from "@/types/user"

export default function Home() {
  const [currentStep, setCurrentStep] = useState<"landing" | "onboarding" | "chat">("landing")
  const [userPreferences, setUserPreferences] = useState<UserPreferences | null>(null)
  const [chatbotName, setChatbotName] = useState("Gogo")

  const handleStartJourney = () => {
    setCurrentStep("onboarding")
  }

  const handleOnboardingComplete = (preferences: UserPreferences, name: string) => {
    setUserPreferences(preferences)
    setChatbotName(name)
    setCurrentStep("chat")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      <AnimatePresence mode="wait">
        {currentStep === "landing" && (
          <motion.div
            key="landing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <LandingPage onStartJourney={handleStartJourney} />
          </motion.div>
        )}

        {currentStep === "onboarding" && (
          <motion.div
            key="onboarding"
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            transition={{ duration: 0.5 }}
          >
            <OnboardingFlow onComplete={handleOnboardingComplete} />
          </motion.div>
        )}

        {currentStep === "chat" && userPreferences && (
          <motion.div
            key="chat"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.5 }}
          >
            <ChatInterfacePure
              userPreferences={userPreferences}
              chatbotName={chatbotName}
              onBack={() => setCurrentStep("onboarding")}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
