interface QlooInsightsRequest {
  "filter.type": string
  "filter.tags"?: string
  "filter.location.query"?: string
  "signal.interests.entities"?: string
  "signal.interests.tags"?: string
  "signal.demographics.audiences"?: string
  "operator.filter.tags"?: string
  limit?: number
}

interface QlooEntity {
  name: string
  entity_id: string
  type: string
  subtype: string
  properties: {
    description?: string
    image?: {
      url: string
    }
    tags?: Array<{
      id: string
      name: string
      type: string
    }>
    popularity?: number
    external?: {
      imdb?: string
      rotten_tomatoes?: string
      spotify?: string
      booking?: string
      [key: string]: any
    }
    [key: string]: any
  }
  query?: {
    affinity?: number
    measurements?: {
      audience_growth?: number
      [key: string]: any
    }
  }
}

interface QlooInsightsResponse {
  success: boolean
  results: {
    entities: QlooEntity[]
  }
  duration: number
}

interface QlooSearchResponse {
  success: boolean
  results: Array<{
    id: string
    name: string
    type: string
    [key: string]: any
  }>
}

interface QlooTagsResponse {
  success: boolean
  results: {
    tags: Array<{
      id: string
      name: string
      type: string
      popularity?: number
      properties?: any
    }>
  }
}

class QlooService {
  private apiKey: string
  private baseUrl: string

  constructor() {
    this.apiKey = process.env.QLOO_API_KEY || ""
    this.baseUrl = process.env.QLOO_API_URL || "https://hackathon.api.qloo.com"
  }

  private async makeRequest(endpoint: string, params?: Record<string, string>): Promise<any> {
    try {
      let url = `${this.baseUrl}${endpoint}`

      if (params) {
        const searchParams = new URLSearchParams(params)
        url += `?${searchParams.toString()}`
      }

      console.log(`Making GET request to: ${url}`)
      console.log(`Headers: X-Api-Key: ${this.apiKey.substring(0, 10)}...`)

      const response = await fetch(url, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "X-Api-Key": this.apiKey,
        },
      })

      console.log(`Response status: ${response.status}`)

      if (!response.ok) {
        const errorText = await response.text()
        console.error(`Qloo API error response:`, errorText)
        throw new Error(`Qloo API error: ${response.status} - ${errorText}`)
      }

      const result = await response.json()
      console.log(`Qloo API success:`, result)
      return result
    } catch (error) {
      console.error("Qloo API request failed:", error)
      throw error
    }
  }

  // NEW: Direct prompt-based recommendations using Qloo's natural language processing
  async getDirectRecommendations(userPrompt: string): Promise<QlooEntity[]> {
    try {
      console.log(`🎯 Getting direct recommendations for prompt: "${userPrompt.substring(0, 100)}..."`)

      // Use insights endpoint with natural language query
      const entityType = this.detectEntityTypeFromPrompt(userPrompt)
      console.log(`🔍 Detected entity type: ${entityType}`)

      const requestParams: Record<string, string> = {
        "filter.type": entityType,
        limit: "10",
      }

      // Add location if detected (but don't force it)
      const location = this.extractLocationFromPrompt(userPrompt)
      if (location && entityType === "urn:entity:place") {
        requestParams["filter.location.query"] = location
        console.log(`📍 Added location filter: ${location}`)
      }

      // For fashion/brands, add style-based tags
      if (entityType === "urn:entity:brand") {
        // Extract style keywords for better brand matching
        const styleKeywords = this.extractStyleKeywords(userPrompt)
        if (styleKeywords.length > 0) {
          // Search for relevant tags first
          const tagIds: string[] = []
          for (const keyword of styleKeywords.slice(0, 3)) {
            const tags = await this.searchTags(keyword)
            const relevantTags = tags.filter(
              (tag) => tag.type?.includes("style") || tag.type?.includes("fashion") || tag.type?.includes("brand"),
            )
            tagIds.push(...relevantTags.slice(0, 2).map((tag) => tag.id))
          }

          if (tagIds.length > 0) {
            requestParams["signal.interests.tags"] = tagIds.join(",")
            console.log(`🏷️ Added style tags: ${tagIds}`)
          }
        }
      }

      // For restaurants, add cuisine-based tags
      if (entityType === "urn:entity:place") {
        const cuisineKeywords = this.extractCuisineKeywords(userPrompt)
        if (cuisineKeywords.length > 0) {
          const tagIds: string[] = []
          for (const keyword of cuisineKeywords.slice(0, 3)) {
            const tags = await this.searchTags(keyword)
            const relevantTags = tags.filter(
              (tag) => tag.type?.includes("cuisine") || tag.type?.includes("food") || tag.type?.includes("dining"),
            )
            tagIds.push(...relevantTags.slice(0, 2).map((tag) => tag.id))
          }

          if (tagIds.length > 0) {
            requestParams["signal.interests.tags"] = tagIds.join(",")
            console.log(`🍽️ Added cuisine tags: ${tagIds}`)
          }
        }
      }

      console.log(`🔧 Final request params:`, requestParams)

      const response: QlooInsightsResponse = await this.makeRequest("/v2/insights", requestParams)
      console.log(`🎯 Direct insights response:`, JSON.stringify(response.results?.entities?.slice(0, 2), null, 2))
      return response.results?.entities || []
    } catch (error) {
      console.error("Failed to get direct recommendations:", error)
      return []
    }
  }

  // Extract style keywords from fashion descriptions
  private extractStyleKeywords(prompt: string): string[] {
    const lowerPrompt = prompt.toLowerCase()
    const keywords: string[] = []

    // Style descriptors
    if (lowerPrompt.includes("bohemian")) keywords.push("bohemian")
    if (lowerPrompt.includes("casual")) keywords.push("casual")
    if (lowerPrompt.includes("summer")) keywords.push("summer")
    if (lowerPrompt.includes("maxi")) keywords.push("maxi")
    if (lowerPrompt.includes("flowing")) keywords.push("flowing")
    if (lowerPrompt.includes("feminine")) keywords.push("feminine")
    if (lowerPrompt.includes("romantic")) keywords.push("romantic")
    if (lowerPrompt.includes("beachwear")) keywords.push("beachwear")
    if (lowerPrompt.includes("tiered")) keywords.push("tiered")
    if (lowerPrompt.includes("ruffles")) keywords.push("ruffles")

    return keywords
  }

  // Extract cuisine keywords from food descriptions
  private extractCuisineKeywords(prompt: string): string[] {
    const lowerPrompt = prompt.toLowerCase()
    const keywords: string[] = []

    // Cuisine types
    if (lowerPrompt.includes("indian")) keywords.push("indian")
    if (lowerPrompt.includes("street food")) keywords.push("street food")
    if (lowerPrompt.includes("comfort food")) keywords.push("comfort food")
    if (lowerPrompt.includes("casual dining")) keywords.push("casual dining")
    if (lowerPrompt.includes("pav bhaji")) keywords.push("indian street food")
    if (lowerPrompt.includes("spicy")) keywords.push("spicy")
    if (lowerPrompt.includes("vibrant")) keywords.push("vibrant")

    return keywords
  }

  // Detect entity type from user prompt
  private detectEntityTypeFromPrompt(prompt: string): string {
    const lowerPrompt = prompt.toLowerCase()

    // Fashion/Clothing detection (more specific patterns)
    if (
      lowerPrompt.includes("dress") ||
      lowerPrompt.includes("fashion") ||
      lowerPrompt.includes("clothing") ||
      lowerPrompt.includes("maxi dress") ||
      lowerPrompt.includes("bohemian fashion") ||
      lowerPrompt.includes("summer") ||
      lowerPrompt.includes("outfit") ||
      lowerPrompt.includes("style") ||
      lowerPrompt.includes("brand") ||
      lowerPrompt.includes("apparel") ||
      lowerPrompt.includes("wear")
    ) {
      return "urn:entity:brand"
    }

    // Food/Restaurant detection
    if (
      lowerPrompt.includes("restaurant") ||
      lowerPrompt.includes("food") ||
      lowerPrompt.includes("eat") ||
      lowerPrompt.includes("dining") ||
      lowerPrompt.includes("brunch") ||
      lowerPrompt.includes("lunch") ||
      lowerPrompt.includes("dinner") ||
      lowerPrompt.includes("cafe") ||
      lowerPrompt.includes("bar") ||
      lowerPrompt.includes("pav bhaji") ||
      lowerPrompt.includes("indian cuisine") ||
      lowerPrompt.includes("street food") ||
      lowerPrompt.includes("comfort food")
    ) {
      return "urn:entity:place"
    }

    // Movie detection
    if (
      lowerPrompt.includes("movie") ||
      lowerPrompt.includes("film") ||
      lowerPrompt.includes("cinema") ||
      lowerPrompt.includes("watch")
    ) {
      return "urn:entity:movie"
    }

    // Music detection
    if (
      lowerPrompt.includes("music") ||
      lowerPrompt.includes("song") ||
      lowerPrompt.includes("artist") ||
      lowerPrompt.includes("album") ||
      lowerPrompt.includes("playlist")
    ) {
      return "urn:entity:artist"
    }

    // Travel detection
    if (
      lowerPrompt.includes("travel") ||
      lowerPrompt.includes("destination") ||
      lowerPrompt.includes("trip") ||
      lowerPrompt.includes("vacation")
    ) {
      return "urn:entity:destination"
    }

    // Default fallback - analyze content to make best guess
    if (lowerPrompt.includes("type: this is a fashion") || lowerPrompt.includes("clothing item")) {
      return "urn:entity:brand"
    }

    if (lowerPrompt.includes("type: this is a food") || lowerPrompt.includes("dish")) {
      return "urn:entity:place"
    }

    // Final fallback
    return "urn:entity:place"
  }

  // Extract location from user prompt
  private extractLocationFromPrompt(prompt: string): string | null {
    const lowerPrompt = prompt.toLowerCase()

    if (lowerPrompt.includes("nyc") || lowerPrompt.includes("new york")) {
      return "New York City"
    }

    if (lowerPrompt.includes("paris")) {
      return "Paris"
    }

    if (lowerPrompt.includes("london")) {
      return "London"
    }

    if (lowerPrompt.includes("los angeles") || lowerPrompt.includes("la")) {
      return "Los Angeles"
    }

    if (lowerPrompt.includes("san francisco") || lowerPrompt.includes("sf")) {
      return "San Francisco"
    }

    if (lowerPrompt.includes("chicago")) {
      return "Chicago"
    }

    if (lowerPrompt.includes("miami")) {
      return "Miami"
    }

    if (lowerPrompt.includes("tokyo")) {
      return "Tokyo"
    }

    return null
  }

  // Search for entities by name to get their IDs
  async searchEntities(query: string, types?: string[]): Promise<any[]> {
    try {
      const params: Record<string, string> = { query }
      if (types && types.length > 0) {
        params.types = types.join(",")
      }

      const response = await this.makeRequest("/search", params)
      return response.results || []
    } catch (error) {
      console.error("Failed to search entities:", error)
      return []
    }
  }

  // Search for tags by name to get their IDs
  async searchTags(query: string): Promise<any[]> {
    try {
      const response = await this.makeRequest("/v2/tags", { "filter.query": query })
      return response.results?.tags || []
    } catch (error) {
      console.error("Failed to search tags:", error)
      return []
    }
  }

  // Get insights/recommendations using the proper Qloo API format
  async getInsights(filterType: string, params: Record<string, string> = {}): Promise<QlooEntity[]> {
    try {
      const requestParams: Record<string, string> = {
        "filter.type": filterType,
        ...params,
      }

      // Remove undefined values
      Object.keys(requestParams).forEach((key) => {
        if (requestParams[key] === undefined || requestParams[key] === "") {
          delete requestParams[key]
        }
      })

      const response: QlooInsightsResponse = await this.makeRequest("/v2/insights", requestParams)
      console.log(`🎯 Insights response:`, JSON.stringify(response.results?.entities?.slice(0, 2), null, 2))
      return response.results?.entities || []
    } catch (error) {
      console.error("Failed to get insights:", error)
      return []
    }
  }

  async getMusicRecommendations(preferences: string[], mood: string, numResults = 3): Promise<QlooEntity[]> {
    try {
      console.log(`🎵 Getting music recommendations for preferences: ${preferences}, mood: ${mood}`)

      // Map mood to music descriptors
      const moodMusicMap: Record<string, string> = {
        happy: "upbeat",
        sad: "melancholic",
        excited: "energetic",
        calm: "ambient",
        anxious: "soothing",
        nostalgic: "classic",
        romantic: "romantic",
        neutral: "popular",
      }

      const searchQueries = [...preferences, moodMusicMap[mood] || "popular"].filter(Boolean)

      // Search for relevant music tags
      const allTagIds: string[] = []
      for (const query of searchQueries.slice(0, 3)) {
        console.log(`🔍 Searching tags for: ${query}`)
        const tags = await this.searchTags(query)
        console.log(`Found ${tags.length} tags for "${query}"`)

        // Filter for music-related tags
        const musicTags = tags.filter(
          (tag) =>
            tag.type?.includes("music") ||
            tag.type?.includes("genre") ||
            tag.type?.includes("artist") ||
            tag.name?.toLowerCase().includes("music"),
        )

        console.log(
          `Filtered to ${musicTags.length} music tags:`,
          musicTags.map((t) => t.name),
        )
        allTagIds.push(...musicTags.slice(0, 2).map((tag) => tag.id))
      }

      console.log(`🏷️ Using tag IDs: ${allTagIds.slice(0, 5)}`)

      // Build insights request parameters
      const insightsParams: Record<string, string> = {}

      if (allTagIds.length > 0) {
        insightsParams["signal.interests.tags"] = allTagIds.slice(0, 5).join(",")
      } else {
        // Fallback: use popularity filter if no tags found
        insightsParams["filter.popularity.min"] = "0.5"
      }

      console.log(`🎯 Making insights request with params:`, insightsParams)
      return await this.getInsights("urn:entity:artist", insightsParams)
    } catch (error) {
      console.error("Failed to get music recommendations:", error)
      return []
    }
  }

  async getMovieRecommendations(preferences: string[], mood: string, numResults = 3): Promise<QlooEntity[]> {
    try {
      console.log(`🎬 Getting movie recommendations for preferences: ${preferences}, mood: ${mood}`)

      // Map mood to movie genres
      const moodMovieMap: Record<string, string> = {
        happy: "comedy",
        sad: "drama",
        excited: "action",
        calm: "documentary",
        anxious: "comedy",
        nostalgic: "classic",
        romantic: "romance",
        neutral: "popular",
      }

      const searchQueries = [...preferences, moodMovieMap[mood] || "popular"].filter(Boolean)

      // Search for relevant movie tags
      const allTagIds: string[] = []
      for (const query of searchQueries.slice(0, 3)) {
        const tags = await this.searchTags(query)
        const movieTags = tags.filter(
          (tag) =>
            tag.type?.includes("genre") ||
            tag.type?.includes("movie") ||
            tag.type?.includes("media") ||
            tag.type?.includes("film"),
        )
        allTagIds.push(...movieTags.slice(0, 2).map((tag) => tag.id))
      }

      const insightsParams: Record<string, string> = {}

      if (allTagIds.length > 0) {
        insightsParams["signal.interests.tags"] = allTagIds.slice(0, 5).join(",")
      } else {
        insightsParams["filter.popularity.min"] = "0.5"
      }

      return await this.getInsights("urn:entity:movie", insightsParams)
    } catch (error) {
      console.error("Failed to get movie recommendations:", error)
      return []
    }
  }

  async getRestaurantRecommendations(
    preferences: string[],
    mood: string,
    location?: string,
    numResults = 3,
  ): Promise<QlooEntity[]> {
    try {
      console.log(`🍽️ Getting restaurant recommendations for preferences: ${preferences}, mood: ${mood}`)

      const moodRestaurantMap: Record<string, string> = {
        happy: "vibrant",
        sad: "comfort food",
        excited: "trendy",
        calm: "quiet",
        anxious: "casual",
        nostalgic: "traditional",
        romantic: "intimate",
        neutral: "popular",
      }

      const searchQueries = [...preferences, moodRestaurantMap[mood] || "restaurant"].filter(Boolean)

      // Search for relevant restaurant/cuisine tags
      const allTagIds: string[] = []
      for (const query of searchQueries.slice(0, 3)) {
        const tags = await this.searchTags(query)
        const restaurantTags = tags.filter(
          (tag) =>
            tag.type?.includes("cuisine") ||
            tag.type?.includes("place") ||
            tag.type?.includes("restaurant") ||
            tag.type?.includes("dining") ||
            tag.type?.includes("food"),
        )
        allTagIds.push(...restaurantTags.slice(0, 2).map((tag) => tag.id))
      }

      const insightsParams: Record<string, string> = {}

      if (allTagIds.length > 0) {
        insightsParams["signal.interests.tags"] = allTagIds.slice(0, 5).join(",")
      } else {
        insightsParams["filter.popularity.min"] = "0.3"
      }

      // Add location if provided (following the example format)
      if (location) {
        insightsParams["filter.location.query"] = location
      }

      return await this.getInsights("urn:entity:place", insightsParams)
    } catch (error) {
      console.error("Failed to get restaurant recommendations:", error)
      return []
    }
  }

  async getBrandRecommendations(preferences: string[], mood: string, numResults = 3): Promise<QlooEntity[]> {
    try {
      console.log(`👗 Getting brand recommendations for preferences: ${preferences}, mood: ${mood}`)

      const searchQueries = [...preferences, "fashion", "brand"].filter(Boolean)

      const allTagIds: string[] = []
      for (const query of searchQueries.slice(0, 3)) {
        const tags = await this.searchTags(query)
        const brandTags = tags.filter(
          (tag) =>
            tag.type?.includes("brand") ||
            tag.type?.includes("fashion") ||
            tag.type?.includes("style") ||
            tag.type?.includes("clothing"),
        )
        allTagIds.push(...brandTags.slice(0, 2).map((tag) => tag.id))
      }

      const insightsParams: Record<string, string> = {}

      if (allTagIds.length > 0) {
        insightsParams["signal.interests.tags"] = allTagIds.slice(0, 5).join(",")
      } else {
        insightsParams["filter.popularity.min"] = "0.3"
      }

      return await this.getInsights("urn:entity:brand", insightsParams)
    } catch (error) {
      console.error("Failed to get brand recommendations:", error)
      return []
    }
  }

  async getTravelRecommendations(preferences: string[], mood: string, numResults = 3): Promise<QlooEntity[]> {
    try {
      console.log(`✈️ Getting travel recommendations for preferences: ${preferences}, mood: ${mood}`)

      const moodTravelMap: Record<string, string> = {
        happy: "fun",
        sad: "peaceful",
        excited: "adventure",
        calm: "serene",
        anxious: "safe",
        nostalgic: "historic",
        romantic: "romantic",
        neutral: "popular",
      }

      const searchQueries = [...preferences, moodTravelMap[mood] || "destination"].filter(Boolean)

      const allTagIds: string[] = []
      for (const query of searchQueries.slice(0, 3)) {
        const tags = await this.searchTags(query)
        const travelTags = tags.filter(
          (tag) =>
            tag.type?.includes("destination") ||
            tag.type?.includes("travel") ||
            tag.type?.includes("place") ||
            tag.type?.includes("location"),
        )
        allTagIds.push(...travelTags.slice(0, 2).map((tag) => tag.id))
      }

      const insightsParams: Record<string, string> = {}

      if (allTagIds.length > 0) {
        insightsParams["signal.interests.tags"] = allTagIds.slice(0, 5).join(",")
      } else {
        insightsParams["filter.popularity.min"] = "0.3"
      }

      return await this.getInsights("urn:entity:destination", insightsParams)
    } catch (error) {
      console.error("Failed to get travel recommendations:", error)
      return []
    }
  }

  // Enhanced location-based recommendations using WKT shapes
  async getLocationBasedRecommendations(
    wktShape: string,
    filterType: string,
    additionalParams: Record<string, string> = {},
  ): Promise<QlooEntity[]> {
    try {
      console.log(`🗺️ Getting location-based recommendations for WKT: ${wktShape.substring(0, 100)}...`)

      const requestParams: Record<string, string> = {
        "filter.type": filterType,
        "filter.location.wkt": wktShape,
        limit: "10",
        ...additionalParams,
      }

      // Ensure we have at least one valid filter
      if (!requestParams["filter.location.wkt"] && !requestParams["filter.location.query"]) {
        console.error("❌ No valid location filter provided")
        return []
      }

      // Remove undefined values
      Object.keys(requestParams).forEach((key) => {
        if (requestParams[key] === undefined || requestParams[key] === "") {
          delete requestParams[key]
        }
      })

      console.log(`🔧 Location request params:`, requestParams)

      const response: QlooInsightsResponse = await this.makeRequest("/v2/insights", requestParams)
      console.log(
        `🎯 Location-based insights response:`,
        JSON.stringify(response.results?.entities?.slice(0, 2), null, 2),
      )
      return response.results?.entities || []
    } catch (error) {
      console.error("Failed to get location-based recommendations:", error)
      return []
    }
  }

  // Get demographic insights with affinity scores
  async getDemographicInsights(entities: string[], tags: string[] = [], audiences: string[] = []): Promise<any> {
    try {
      console.log(`👥 Getting demographic insights for entities: ${entities}, tags: ${tags}`)

      if (entities.length === 0 && tags.length === 0 && audiences.length === 0) {
        console.error("❌ No valid signals provided for demographic insights")
        return { entities: [] }
      }

      const requestParams: Record<string, string> = {
        "filter.type": "urn:entity:movie", // Default to movies for demographic analysis
        limit: "10",
      }

      if (entities.length > 0) {
        requestParams["signal.interests.entities"] = entities.join(",")
      }

      if (tags.length > 0) {
        requestParams["signal.interests.tags"] = tags.join(",")
      }

      if (audiences.length > 0) {
        requestParams["signal.demographics.audiences"] = audiences.join(",")
      }

      console.log(`🔧 Demographic request params:`, requestParams)

      const response = await this.makeRequest("/v2/insights", requestParams)
      console.log(`📊 Demographic insights:`, JSON.stringify(response.results, null, 2))
      return response.results || { entities: [] }
    } catch (error) {
      console.error("Failed to get demographic insights:", error)
      return { entities: [] }
    }
  }

  // Search for specific entities (like actors, brands) to get their IDs
  async searchSpecificEntities(query: string, entityType: string): Promise<any[]> {
    try {
      console.log(`🔍 Searching for ${entityType}: ${query}`)

      const params: Record<string, string> = {
        query,
        "filter.type": entityType,
      }

      const response = await this.makeRequest("/search", params)
      console.log(`Found ${response.results?.length || 0} entities for "${query}"`)
      return response.results || []
    } catch (error) {
      console.error("Failed to search specific entities:", error)
      return []
    }
  }

  // Get affinity scores between entities
  async getAffinityScores(
    sourceEntities: string[],
    targetEntities: string[],
    filterType: string,
  ): Promise<QlooEntity[]> {
    try {
      console.log(`🎯 Getting affinity scores between entities`)
      console.log(`Source entities: ${sourceEntities}`)
      console.log(`Target entities: ${targetEntities}`)

      if (sourceEntities.length === 0) {
        console.error("❌ No source entities provided for affinity scores")
        return []
      }

      const requestParams: Record<string, string> = {
        "filter.type": filterType,
        "signal.interests.entities": sourceEntities.join(","),
        limit: "10",
      }

      // Add target entities as additional signals if provided
      if (targetEntities.length > 0) {
        requestParams["signal.interests.tags"] = targetEntities.join(",")
      }

      console.log(`🔧 Affinity request params:`, requestParams)

      const response: QlooInsightsResponse = await this.makeRequest("/v2/insights", requestParams)

      // Add affinity score information to results
      const entitiesWithAffinity =
        response.results?.entities?.map((entity) => ({
          ...entity,
          affinityScore: entity.query?.affinity || 0,
          measurements: entity.query?.measurements || {},
        })) || []

      console.log(`📊 Affinity scores calculated for ${entitiesWithAffinity.length} entities`)
      return entitiesWithAffinity
    } catch (error) {
      console.error("Failed to get affinity scores:", error)
      return []
    }
  }

  // Paris center WKT shape (example)
  getParisCenterWKT(): string {
    return "POLYGON((2.3522 48.8566, 2.3522 48.8466, 2.3722 48.8466, 2.3722 48.8566, 2.3522 48.8566))"
  }

  // Get popular brands in Paris center
  async getParisPopularBrands(): Promise<QlooEntity[]> {
    try {
      console.log(`🏪 Getting popular brands in Paris center`)

      const parisWKT = this.getParisCenterWKT()

      return await this.getLocationBasedRecommendations(parisWKT, "urn:entity:brand", {
        "filter.popularity.min": "0.5",
        limit: "10",
      })
    } catch (error) {
      console.error("Failed to get Paris brands:", error)
      return []
    }
  }

  // Enhanced search for actors with better filtering
  async searchActors(actorName: string): Promise<string[]> {
    try {
      console.log(`🎭 Searching for actor: ${actorName}`)

      // Try multiple search approaches
      const searchResults = await this.searchEntities(actorName, ["urn:entity:person"])

      if (searchResults.length === 0) {
        // Fallback: search without type filter
        const fallbackResults = await this.searchEntities(actorName)
        const actorResults = fallbackResults.filter(
          (result) =>
            result.type?.includes("person") ||
            result.subtype?.includes("person") ||
            result.name?.toLowerCase().includes(actorName.toLowerCase()),
        )

        console.log(`🎭 Found ${actorResults.length} actors via fallback search`)
        return actorResults.slice(0, 3).map((result) => result.id)
      }

      console.log(`🎭 Found ${searchResults.length} actors via direct search`)
      return searchResults.slice(0, 3).map((result) => result.id)
    } catch (error) {
      console.error(`Failed to search for actor ${actorName}:`, error)
      return []
    }
  }

  // Get recommendations by city name (simpler than WKT)
  async getLocationRecommendations(
    cityName: string,
    filterType: string,
    additionalParams: Record<string, string> = {},
  ): Promise<QlooEntity[]> {
    try {
      console.log(`🏙️ Getting recommendations for city: ${cityName}`)

      const requestParams: Record<string, string> = {
        "filter.type": filterType,
        "filter.location.query": cityName,
        limit: "10",
        ...additionalParams,
      }

      // Remove undefined values
      Object.keys(requestParams).forEach((key) => {
        if (requestParams[key] === undefined || requestParams[key] === "") {
          delete requestParams[key]
        }
      })

      console.log(`🔧 City location request params:`, requestParams)

      const response: QlooInsightsResponse = await this.makeRequest("/v2/insights", requestParams)
      console.log(`🎯 City-based insights response:`, JSON.stringify(response.results?.entities?.slice(0, 2), null, 2))
      return response.results?.entities || []
    } catch (error) {
      console.error("Failed to get city-based recommendations:", error)
      return []
    }
  }
}

export const qlooService = new QlooService()
export type { QlooEntity }
