const fs = require("fs")
const path = require("path")

// Create .env.local file with template
const envTemplate = `# API Keys - Replace with your actual keys
OPENAI_API_KEY=your_openai_api_key_here
QLOO_API_KEY=your_qloo_api_key_here

# Server Configuration
PORT=3001
NODE_ENV=development

# Frontend URL for CORS
FRONTEND_URL=http://localhost:3000
`

const envPath = path.join(process.cwd(), ".env.local")

if (!fs.existsSync(envPath)) {
  fs.writeFileSync(envPath, envTemplate)
  console.log("✅ Created .env.local file")
  console.log("🔑 Please add your OpenAI and Qloo API keys to .env.local")
} else {
  console.log("⚠️  .env.local already exists")
}
