export interface UserPreferences {
  name: string
  favoriteMovies: string[]
  favoriteMusic: string[]
  favoriteFood: string[]
  favoritePlaces: string[]
  fashionStyle: string[]
  personalityType: string
  movieGenres: string[]
  musicGenres: string[]
  foodTypes: string[]
  travelTypes: string[]
  additionalInfo: string
}

export type MoodType = "happy" | "sad" | "excited" | "calm" | "anxious" | "nostalgic" | "neutral" | "romantic"

export interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp?: Date
}

export interface ChatContext {
  userPreferences: UserPreferences
  currentMood: MoodType
  chatbotName: string
}
